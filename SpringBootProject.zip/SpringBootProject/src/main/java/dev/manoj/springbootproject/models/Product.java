package dev.manoj.springbootproject.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Product {
    int productId;
    int quantity;
}
