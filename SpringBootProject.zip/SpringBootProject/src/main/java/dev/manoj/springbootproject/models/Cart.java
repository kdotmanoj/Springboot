package dev.manoj.springbootproject.models;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    private Long id;
    private List<Product> products;
}